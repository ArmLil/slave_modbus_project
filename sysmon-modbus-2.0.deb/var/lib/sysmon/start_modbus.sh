#!/bin/bash

. /var/lib/sysmon/nvm-modbus/nvm.sh
node /var/lib/sysmon/modbus/index.js
